# I have issues

## I'm submitting a...

* [ ] bug report
* [ ] feature request
* [ ] support request - read the [FAQ](https://github.com/terraform-aws-modules/terraform-aws-eks/blob/master/docs/faq.md) first!
* [ ] kudos, thank you, warm fuzzy

## What is the current behavior?



## If this is a bug, how to reproduce? Please include a code sample if relevant.



## What's the expected behavior?



## Are you able to fix this problem and submit a PR? Link here if you have already.

## Environment details

* Affected module version:
* OS:
* Terraform version:

## Any other relevant info
